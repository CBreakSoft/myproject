package com.cp.jsp.unit;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * 2017.5.6 
 * chenpeng
 * 连接数据库的工具类
 * 用于实现数据库的连接、断开等操作
 */
public class DBUnit {
  //dbdzsw为数据库的名字，db_user为数据库的名字，db_password为数据库的密码    useUnicode=true&characterEncoding=UTF-8--指定字符的编码、解码格式。
  public static String db_url="jdbc:mysql://localhost:3306/dbdzsw?useUnicode=true&characterEncoding=UTF-8";
  public static String db_user="root";
  public static String db_password="root";
  //数据库的连接;此处导入了import java.sql.Connection和DriverManager;
  public static Connection getConn()
  {
	  Connection conn=null;
	  try {
		  Class.forName("com.mysql.jdbc.Driver");
		  conn=DriverManager.getConnection(db_url, db_user, db_password);
		
	} catch (Exception e) {
		e.printStackTrace();
	}
	  return conn;
  }
  //数据库 状态、连接的关闭 不包含结果集的关闭，此导入了java.sql.Statement/SQLException
  public static void close(Statement state, Connection conn)
  {
	  if(state!=null) {
		  try {
			  state.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	  }
	  if(conn!=null) {
		  try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	  }
  }
  //数据库连接的关闭，包含结果集 此导入了java.sql.ResultSet
  public static void close(ResultSet rs, Statement state, Connection conn)
  {
	  if(rs!=null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(state!=null) {
			try {
				state.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(conn!=null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
  }
}
