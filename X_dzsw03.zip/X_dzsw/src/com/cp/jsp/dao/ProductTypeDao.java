package com.cp.jsp.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cp.jsp.bean.ProductTypeBean;
import com.cp.jsp.unit.DBUnit;

/** 
*	商品分类DAO 
*	@author
*   chenpeng 
*   20170526
*/ 

public class ProductTypeDao {
	

	/** 
	*	删除商品类型 
    *  
	*	@param id 
	*	@return 
    */ 
	public boolean delete(int id) {  
	  boolean f = true; 
	  //删除子分类 
	  List<ProductTypeBean>typeList = getTypeList(id); 
	  
	  for(ProductTypeBean typeBean : typeList){  
		  
	   boolean f1 = delete(typeBean.getId()); 
	   
	   if(!f1){   
		  f = false; 
	   } 
	  } 
	  String sql = "delete from product_type where id='" + id + "'"; 
	  
	  Connection conn = DBUnit.getConn();
	  
	  Statement state = null; 
	  
	  int a = 0; 
	  try { 
		  
	   state = conn.createStatement();  
	   
	   a = state.executeUpdate(sql); 
	  } catch (Exception e) { 
		  
	   e.printStackTrace(); 
	   
	  } finally { 
		  
	   DBUnit.close(state, conn); 
	   
	  } 
	  if (a == 0) {	 
		  
		  f = false;
	  }
	  return f; 
	 } 

	/** 
	*	通过父分类id获取子分类列表 
	*   id, name, sort, intro, createDate信息的封装
	*	@return 
	*/ 
	public List<ProductTypeBean>getTypeList(int parentId){
		//通过父分类id获取子分类列表
		// String sql = "select * from product_type where parent_id='"+parentId+"'"; 
		 String sql = "select * from product_type where parent_id='"+parentId+"'"; 
		//定义ProductTypeBean的List泛型list
		List<ProductTypeBean>list=new ArrayList<ProductTypeBean>();
		//连接数据库
		Connection conn=DBUnit.getConn();
		//创建 状态集，结果集 对象
		Statement state=null;
		ResultSet rs=null;
		//获取执行sql语句，try、catch异常抛出
		try {
			//创建状态集
			state=conn.createStatement();
			//单次结果集 executeQuery 用于产生单个结果集的语句
			rs=state.executeQuery(sql);
			//定义ProductTypeBean类的变量productTypeBean
			ProductTypeBean productTypeBean=null;
			//
			while(rs.next()){
				//获取对应数据库表的信息商品id，name
				int id=rs.getInt("id");
				String name=rs.getString("name");
				int sort=rs.getInt("sort");
				String intro=rs.getString("intro");
				String createDate=rs.getString("create_date");
				productTypeBean=new ProductTypeBean(id, name, sort, intro, createDate);
				list.add(productTypeBean);
			}
		} catch (Exception e) {
			// TODO: handle exception
			//e.printStackTrace()当try语句中出现异常是时.会执行catch中的语句.java运行时系统会自动将catch括号中的Exception e 初始化.也就是实例化Exception类型的对象.e是此对象引用名称.然后e(引用)会自动调用Exception类中指定的方法.也就出现了e.printStackTrace().
			//?printStackTrace()意思在命令行打印异常信息在程序中出错的位置及原因.
			e.printStackTrace();
		}finally{
			//关闭数据库
			DBUnit.close(rs, state, conn);
		}
		return list;
	}

	
	/** 
	*	通过父分类id获取子分类列表 
	*	ProductTypeBean 只封装id,name, 
	*	@return 
	*/ 
	public List<ProductTypeBean>getTypeBeans(int parentId){
		//通过父分类id获取子分类列表
		String sql="select * from product_type where parent_id='"+parentId+"'";
		//定义ProductTypeBean的List泛型typeBeans
		List<ProductTypeBean>typeBeans=new ArrayList<ProductTypeBean>();
		//连接数据库
		Connection conn=DBUnit.getConn();
		//创建 状态集，结果集 对象
		Statement state=null;
		ResultSet rs=null;
		//获取执行sql语句，try、catch异常抛出
		try {
			//创建状态集
			state=conn.createStatement();
			//单次结果集 executeQuery 用于产生单个结果集的语句
			rs=state.executeQuery(sql);
			//定义ProductTypeBean类的变量productTypeBean
			ProductTypeBean productTypeBean=null;
			//
			while(rs.next()){
				//获取对应数据库表的信息商品id，name
				int id=rs.getInt("id");
				String name=rs.getString("name");
				//调用参数方法，将id，name赋值？封装是什么意思？
				productTypeBean=new ProductTypeBean(id,name);
				typeBeans.add(productTypeBean);
			}
		} catch (Exception e) {
			// TODO: handle exception
			//e.printStackTrace()当try语句中出现异常是时.会执行catch中的语句.java运行时系统会自动将catch括号中的Exception e 初始化.也就是实例化Exception类型的对象.e是此对象引用名称.然后e(引用)会自动调用Exception类中指定的方法.也就出现了e.printStackTrace().
			//?printStackTrace()意思在命令行打印异常信息在程序中出错的位置及原因.
			e.printStackTrace();
		}finally{
			//关闭数据库
			DBUnit.close(rs, state, conn);
		}
		return typeBeans;
	}
	 /** 
	  * 添加分类
	  * 判断是否添加成功 
	  */ 
     public boolean add(ProductTypeBean productTypeBean){
       //插入语句
	   //String sql = "insert into product_type(name,parent_id,sort,intro,create_date) values('" + productTypeBean.getName() + "','" + productTypeBean.getParentId() + "','" + productTypeBean.getSort() + "','" + productTypeBean.getIntro() + "',now())"; 
	   String sql="insert into product_type(name,parent_id,sort,intro,create_date)values('"+productTypeBean.getName()+"','"+productTypeBean.getParentId()+"','"+productTypeBean.getSort()+"','"+productTypeBean.getIntro()+"',now())";
       //建立数据库连接
	   Connection conn=DBUnit.getConn();
	  //状态集
	  Statement state=null;
	  //定义判断变量充当返回集
	  boolean f=false;
	  int a=0;
	  try {
		  state =conn.createStatement();
		  //executeUpdate返回值为int类型，a用来看语句是否成功插入
		  a=state.executeUpdate(sql);
	   } catch (Exception e) {
	 	// TODO: handle exception
	 	e.printStackTrace();
	  }finally{
	  DBUnit.close(state, conn);	
	  }
	  if(a>0){
		f=true;
	  }
	return f;
	}

     /** 
     *	更新分类数据 
     *  
     *	@param productTypeBean 
     *	@return 
     */ 

     public boolean update(ProductTypeBean productTypeBean) { 
    	 /*System.out.println("修改后的商品名"+productTypeBean.getName());
    	 System.out.println("修改后的商品序号"+productTypeBean.getSort());
    	 System.out.println("修改后的商简介"+productTypeBean.getIntro());
    	
    	 System.out.println("要修改的商频id"+productTypeBean. getId());*/
    	 //String sql = "update product_type set name='" + productTypeBean.getName() + "', sort='" + productTypeBean.getSort()     + "', intro='" + productTypeBean.getIntro() + "' where id='" + productTypeBean.getId() + "'"; 

    	 String sql = "update product_type set name='" + productTypeBean.getName() + "', sort='" + productTypeBean.getSort()     + "', intro='" + productTypeBean.getIntro() + "' where id='" + productTypeBean.getId() + "'"; 
    		   
    	 Connection conn = DBUnit.getConn();  
    		   
    	  Statement state = null;
    		 
    	  boolean f = false;
    		 
    	  int a = 0;
    		 
    	  try {
    			   
          state = conn.createStatement();   
    		  
          a = state.executeUpdate(sql); 
          
          //System.out.println("a的值为： "+a);
    		  
    		
    	  } catch (Exception e) {
    		  e.printStackTrace(); 
    	  } finally { 
    		DBUnit.close(state, conn); 
    	  } 
    	 if (a > 0) {   
    	    f = true; 
    	  } 
    	 return f; 
        } 

     
     
     
/** 
*  通过id得到分类类型
*	@param id 
*	@return  
**/ 
public ProductTypeBean getTypeById(int typeId){
	String sql="select * from product_type where id='"+typeId+"'";
	Connection conn=DBUnit.getConn();
	Statement state=null;
	ResultSet rs=null;
	ProductTypeBean productTypeBean=null;
	try {
		state=conn.createStatement();
		rs=state.executeQuery(sql);
		while(rs.next()){
			int id=rs.getInt("id");
			int sort=rs.getInt("sort");
			int parentId=rs.getInt("parent_id");
			String name=rs.getString("name");
			String intro=rs.getString("intro");
			String createDate=rs.getString("create_date");
			ProductTypeDao productTypeDao=new ProductTypeDao();
			ProductTypeBean parentBean=productTypeDao.getTypeById(parentId);
			productTypeBean=new ProductTypeBean(id, sort, parentBean, name, intro, createDate);
		}
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}finally{
		DBUnit.close(rs, state, conn);
	}
	return productTypeBean;
}

/** 
*   获取一个分类 
*	包含所有的父类 
*	包含一级子类list 
*	@param i 
*	@param j 
*	@param id 
*	@return  
**/ 
public ProductTypeBean getType(int id){
	
	List<ProductTypeBean>list=getTypeList(id);
	ProductTypeBean productTypeBean;
	if(id==0){
		productTypeBean=new ProductTypeBean();
		productTypeBean.setId(0);
	}else{
		//?
		productTypeBean=getTypeById(id);
	}
	productTypeBean.setChildBeans(list);
	
	return productTypeBean;
}

}
