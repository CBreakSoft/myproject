package com.cp.jsp.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cp.jsp.bean.AdminBean;
import com.cp.jsp.unit.DBUnit;
import com.cp.jsp.unit.MD5;

/**
 * 2017.5.6
 * chenpeng
 * 数据库的访问层Dao
 * 用于对admin表数据库操作
 * 
 * */
public class AdminDao {

	private DBUnit DBUtil;

	/**
	 * 登录
	 * 
	 * 获取从Servlet层中传递的参数 username、password
	 * 
	 */
	//判断登录
	public AdminBean checkLogin(String username, String password)
	{
		//获取DBUnit中的数据库连接
		Connection conn = DBUnit.getConn();
		AdminBean adminBean = null;
		System.out.println("---------------------AdminDao--------------------");
		System.out.println("此时传递的密码为"+password);
		try {
			Statement state = conn.createStatement();
			//通过用户名获取admin表中的密码
			ResultSet rs = state.executeQuery("select * from admin where username='" + username + "'");
			if (rs.next()) {
				// 如果有结果，是认为是通过验证了
				System.out.println("此时的盐值为"+rs.getString("salt"));
				System.out.println("此时加密后的密码与数据库中的盐值为"+(password+rs.getString("salt")));
				System.out.println("加盐后的密码为"+(MD5.GetMD5Code(password+rs.getString("salt"))));
				System.out.println("此时的密码为"+rs.getString("password"));
				if (rs.getString("password").equals(MD5.GetMD5Code(password+rs.getString("salt")))) {
					
					adminBean = new AdminBean();
					adminBean.setId(rs.getInt("id"));
					adminBean.setUsername(rs.getString("username"));
					adminBean.setPassword(rs.getString("password"));
					adminBean.setSalt(rs.getString("salt"));
					adminBean.setCreateDate(rs.getString("create_date"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return adminBean;
	}
	
	/** 
	*	判断管理员是否已经存在
	*  
	*	@return 
    */ 
	public boolean checkReg(String name){
		boolean flag = true; 
		//查询用户是否存在
		//与数据库建立连接
		Connection connection=DBUnit.getConn();
		//状态
		Statement statement=null;
		//结果集
		ResultSet rs=null;
		try {
			//创建状态
			statement=connection.createStatement();
			//获取admin数据表下username的结果集
			rs=statement.executeQuery("select username from admin ");
			while(rs.next())
			{
				//将获取的name与数据库中的username进行比较
				if(name.equals(rs.getString("username")))
				{
					//如果匹配则说明该用户已存在
					flag=false;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//调用DBUnit中的close的方法顺次关闭数据库
			DBUnit.close(rs, statement, connection);
		}
		return flag;
	}
	
	
	/** 
	*	添加管理员
	*  
	*	@return 
    */ 
	public void save(AdminBean adminBean){
		//添加管理员信息的sql语句
		String sql="insert into admin(username,password,salt,create_date) values ('"
				+adminBean.getUsername()+"','"+adminBean.getPassword()+"','"+adminBean.getSalt()+"','"+adminBean.getCreateDate()+"')";
	   //数据库连接
		Connection conn=DBUnit.getConn();
	   //数据库状态
		Statement state=null;
		//获取执行sql语句，try、catch异常抛出
		try {
			//创建状态集
			state=conn.createStatement();
			//executeUpdate? executeQuery 用于产生单个结果集的语句
			state.executeUpdate(sql);
		} catch (Exception e) {
			//?printStackTrace()意思在命令行打印异常信息在程序中出错的位置及原因.
			e.printStackTrace();
		}finally{
		//最后关闭数据库
		DBUnit.close(state, conn);
		}
	}
	/** 
	*	查看管理员 
	*  
	*	@return 
    */ 
	public List<AdminBean> list() {
		//查询admin数据表中的所有信息并复值给String类型的sql
		String sql="select *from admin";
		//获取数据库的连接
		Connection connection =DBUnit.getConn();
		//定义状态集
		Statement statement=null;
		//定义结果集
		ResultSet resultSet=null;
		//定义一个泛型list的集合，只能存放AdminBean这个对象
		//使用泛型好处就是List遍历出来后(若没有说明的对象那默认的输出的对象类型为Object)不需要自己在进行强制类型转换，系统会自动帮助转换；
		//提取数据库行的值、把值封装成Bean对象 ;然后将Bean对象存入ArrayList中;目的是方便前面通过遍历ArrayList；然后通过Bean的get方法来获取数据！
		List<AdminBean>adminBeans=new ArrayList<AdminBean>();
		
		try {
			//获取状态
			//获取状态产生的结果集
			//最基本的ResultSet.
			statement=connection.createStatement();
			resultSet=statement.executeQuery(sql);//用于产生单个结果集的语句，例如 SELECT 语句
			//定义一个AdminBean的对象
			AdminBean adminBean;
			//循环，将获取到的管理员信息都遍历一遍存到adminBeans中
			while(resultSet.next())
			{
				//此处实现了bean（实体类）文件与数据库对应对象的关联（个人理解）
				//new AdminBean()的作用在队中为对象adminBean申请一块空间，实际是在调用父类的构造方法
				adminBean=new AdminBean();
				//为adminBean中对象赋值（将数据库中的值赋予）
				adminBean.setId(resultSet.getInt("id"));
				adminBean.setUsername(resultSet.getString("username"));
				adminBean.setPassword(resultSet.getString("password"));
				adminBean.setSalt(resultSet.getString("salt"));
				adminBean.setCreateDate(resultSet.getString("create_date"));
				//将adminBeaan获取的值付给list数组adminBeans
				adminBeans.add(adminBean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
		//断开数据库连接
			DBUnit.close(resultSet, statement, connection);
		}
		return adminBeans;
	}
	/**
	*	通过 id 获取 adminBean 对象
	*
	*	@param id
	*	@return
	* 第48
	*/
	public AdminBean getById(int id) {
		//定义sql语句通过id获取admin中相应的信息
		String sql="select *from admin where id="+id;
		//连接数据库
		Connection connection=DBUnit.getConn();
		//定义状态集，结果集、AdminBean对象
		Statement statement=null;
		ResultSet resultset=null;
		//=null不能少，通过id查找，与全部信息显示对比；
		AdminBean adminBean = null;
		try {
			statement=connection.createStatement();
			//单个结果集,不用定义List数组集
			resultset=statement.executeQuery(sql);
			while(resultset.next())
			{
				adminBean=new AdminBean();
				adminBean.setId(resultset.getInt("id"));
				adminBean.setUsername(resultset.getString("username"));
				adminBean.setPassword(resultset.getString("password"));
				adminBean.setSalt(resultset.getString("salt"));
				adminBean.setCreateDate(resultset.getString("create_date"));
			}
		} catch (Exception e) {
		  e.printStackTrace();
		}finally{
			//断开数据库连接；
			DBUtil.close(resultset, statement, connection);
		}
		return adminBean;	
	}
	
	/**
	* 修改管理员
	*
	* @param adminBean
	*/
	public void update(AdminBean adminBean){
		//更新数据库的语句
		/*String sql="update admin set username='"+adminBean.getUsername()
		+"',password='"+adminBean.getPassword()
		+"'where id='"+adminBean.getId()+"";  少了个两个""之间'号*/
		String  sql  =  "update  admin  set  username='"+adminBean.getUsername()  + 
				"',password='"  + adminBean.getPassword()
			 	+ "' where id='" + adminBean.getId() + "'";

		Connection conn=DBUnit.getConn();
		Statement state=null;
		try {
			state =conn.createStatement();
			//单条语句的更新
			state.executeUpdate(sql);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			DBUnit.close(state, conn);
		}
	}
	
	/**
	* 通过 id 删除
	*
	* @param id
	*/              
	public void delete(int id) {
		//删除的数据库语句
		String sql="delete from admin where id="+id;
		Connection conn=DBUnit.getConn();
		Statement state=null;
		try {
			state=conn.createStatement();
			//删除、与更新（修改）语句都一样；
			state.executeUpdate(sql);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			DBUnit.close(state, conn);
		}
	}
	
	/** 
	*	获取数据表中数据总量 
	*	@return 
    */ 
	public int getCount() {
		ResultSet rs = null; 
 	 	Statement state = null;  	
 	 	Connection conn = null;  	 	
 	 	int size = 0; 
	 	try { 
 	 	 	conn = DBUtil.getConn();  	 
 	 	 	state = conn.createStatement(); 
 	 	 	rs = state.executeQuery("select count(*) count from admin"); 
 	 	 	if (rs.next()) {  	 
 	 	 	size = rs.getInt("count"); 
	 	 	} 
 	 	 } catch (SQLException e) {  	
 	 		 e.printStackTrace(); 
	 	 	} finally { 
	 	 	 	DBUtil.close(rs, state, conn); 
	 	 	} 
	 	 	return size; 
	}
	/** 
	*	获取每一个分页的数据 
	*	@param start 
	*	@param size 
	*	@return 
    */
	public List<AdminBean> getListByPage(int start, int size) {
		String sql = "select * from admin limit " + start + " , " + size; 
		Connection connection = DBUtil.getConn(); 
		Statement statement = null; 
		ResultSet resultSet = null; 
		List<AdminBean> adminBeans = new ArrayList<AdminBean>();
		try { 
		 	statement = connection.createStatement(); 
		 	resultSet = statement.executeQuery(sql);  
		 	AdminBean adminBean;  
		 	while (resultSet.next()) { 
		 	 	adminBean = new AdminBean();  
		 	 	adminBean.setId(resultSet.getInt("id"));  	
		 	 	adminBean.setUsername(resultSet.getString("username"));  	 
		 	 	adminBean.setPassword(resultSet.getString("password"));  	 
		 	 	adminBean.setSalt(resultSet.getString("salt"));  	 
		 	 	adminBean.setCreateDate(resultSet.getString("create_date"));  	
		 	 	adminBeans.add(adminBean); 
		 	} 
		} catch (Exception e) { 
		 	e.printStackTrace(); 
		} finally { 
		 	DBUtil.close(resultSet, statement, connection); 
		} 
		return adminBeans; 
		} 
}
