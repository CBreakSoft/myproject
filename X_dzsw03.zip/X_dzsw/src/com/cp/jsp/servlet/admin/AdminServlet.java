package com.cp.jsp.servlet.admin;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cp.jsp.bean.AdminBean;
import com.cp.jsp.bean.PagingBean;
import com.cp.jsp.dao.AdminDao;
import com.cp.jsp.unit.Constants;
import com.cp.jsp.unit.MD5;
import com.cp.jsp.unit.StringUtil;

/**
 *
 * 2017.5.6
 * chenpeng
 * admin管理
 * 
 */
//需要继承HttpServlet
public class AdminServlet extends HttpServlet {
  
	//传递时最好用service
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		//获取来自left.jsp中的变量method
		String method = req.getParameter("method");
		if ("login".equals(method)||method.equalsIgnoreCase("login")) {
			//用户登录
			//去找相应的login（，）方法；
			login(req, resp);
		} else if ("addUser".equals(method)) {
			//用户的添加
			addUser(req, resp); 
 	 	} else if ("list".equals(method)) {  
 	 		//调用用户信息显示的方法；
 	 		listUsers(req, resp); 
 	 	} else if ("toUpdate".equals(method)) { 
 	 		//用户信息编辑
 	 		toUpdate(req, resp); 
 	 	} else if ("delete".equals(method)) {
 	 	 	delete(req, resp);
 	 	}else if ("end".equals(method)||method.equalsIgnoreCase("end")) {
 	 		//退出登录
			end(req, resp);
		}
	}
	
	/**
	 * 登录
	 * 
	 * @param req
	 * @param resp
	 * @throws ServletException
	 * @throws IOException
	 */
	private void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		//获取用户名和密码信息（login.jsp界面传递的参数）
		String username = req.getParameter("username");	
		//将获取的密码进行MD5加密
		String password = MD5.GetMD5Code(req.getParameter("password"));
		
		//System.out.print("----------------------------AdminServlet----------------------");
		//System.out.println("未加密的密码为："+req.getParameter("password"));
		//System.out.println("加密后的密码为："+password);
		//定义类AdminDao的对象
		AdminDao adminDao = new AdminDao();
		//定义对象AdminBean用来接收checkLogin返回的adminBean；
		AdminBean adminBean = adminDao.checkLogin(username, password);
		if (adminBean != null) {
			// 登录成功
			//?setAttribute放去哪了
			req.getSession().setAttribute(Constants.SESSION_ADMIN_BEAN, adminBean);
			// req.getRequestDispatcher("main.jsp").forward(req, resp);
			resp.sendRedirect(req.getContextPath() + "/admin/main.jsp");
		} else {
			//登陆失败将信息传递给登录界面
			resp.sendRedirect(req.getContextPath() + "/admin/login.jsp?status=1");
		}
	}
	
	
	
	/** 
	  *  
	*	查看管理员 
	  *  
	*	@param req 
	*	@param resp 
	*	@throws ServletException 
	*	@throws IOException 
	  */ 
	private void listUsers(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { 
		  // TODO Auto-generated method stub   req.setCharacterEncoding("utf-8"); 
		  //System.out.print("调用了该方法");
		  //定义一个String类型变量获取名为“status”的参数
		  String status = req.getParameter("status");  
		  //定义AdminDao的变量adminDao，用于惊醒对数据库的操作
		  AdminDao adminDao = new AdminDao();   
		  //将获取的“currentPage”String类型的参数，通过调用StringUtil的参数转换成int类型
		  int currentPage = StringUtil.StringToInt(req.getParameter("currentPage"));  
		  //通过调用Dao层的方法，来获取数据表中数据总量 
		  int countSize = adminDao.getCount(); 
		  //定义PagingBean的变量pagingBean，并new一个空间；？
		  PagingBean pagingBean = new PagingBean(currentPage, countSize, Constants.PAGE_SIZE_1); 
		 //定义一个泛型list数组adminBeans，获取每一个分页的数据 ？
		  List<AdminBean>adminBeans = adminDao.getListByPage(currentPage * Constants.PAGE_SIZE_1, Constants.PAGE_SIZE_1);   
		  
		  //System.out.print("数值："+adminBeans.size());
		  //？
		  pagingBean.setPrefixUrl(req.getContextPath() + "/admin/adminServlet?method=list");   
		  //？
		  pagingBean.setAnd(true); 
		  
		  req.setAttribute(Constants.SESSION_ADMIN_BEANS, adminBeans); 
		  
		  req.setAttribute("pagingBean", pagingBean);  
		  
		  if (status != null) { 
		      //status？用于jsp界面判断下是哪条信息状态
			  req.getRequestDispatcher("/admin/list.jsp?status=" + status).forward(req, resp); 
		  
		  } else { 
		  
			  req.getRequestDispatcher("/admin/list.jsp").forward(req, resp); 
		  
		  } 
				 
	} 
	/** 
	  *  
	*	添加管理员信息
	  *  和修改
	*	@param req 
	*	@param resp 
	*	@throws ServletException 
	*	@throws IOException 
	  */ 
	public void addUser(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//定义接受的字符类型
		req.setCharacterEncoding("utf-8");
		//定义updateId用来判断是修改还是添加,货哦去传递的参数updateId；
		String updateId=req.getParameter("updateId");
		//定义AdminDao的对象adminDao
		AdminDao adminDao=new AdminDao();
		//定义String类型变量获取add.jsp界面的用户名和密码
		String username=req.getParameter("username");
		String password=req.getParameter("password");
		//定义实体类AdminBean的变量adminBean
		AdminBean adminBean=new AdminBean();
		//给实体类的username赋值
		adminBean.setUsername(username);
		//让盐值获取随机长度为10字符串
		String salt=StringUtil.getRandomString(10);
		//定义变量md5Pwd获取在用盐值加密的密码(实际上就是执行两次md5加密，只是字符串长度不一样)
		String md5Pwd=MD5.GetMD5Code(MD5.GetMD5Code(password)+salt);
		//给实体类的salt赋值
		adminBean.setSalt(salt);
		//给实体类中的password赋值
		adminBean.setPassword(md5Pwd);
		//获取当前存入的时间，使用SimpleDateFormat类
		SimpleDateFormat createDate1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		//给实体类中的createDate赋值
		adminBean.setCreateDate(createDate1.format(new Date()));
		/*
		 * updateId为空时为添加，不为空时则为修改
		 * 
		 * */
		if(!updateId.equals("")){
			//类型转换
			int id=StringUtil.StringToInt(updateId);
			//?作用是啥
			adminBean.setId(id);
			boolean flag=true;
			if(!username.equals(adminDao.getById(id).getUsername())){
				flag=adminDao.checkReg(username);
			}
			if(flag){
				//修改成功，写入数据库
				adminDao.update(adminBean);
				//传递状态2
				resp.sendRedirect("adminServlet?method=list&status=2");
			}else{
				//修改失败
				resp.sendRedirect("add.jsp?status=2");
			}
		}
		else{
		//判断是否该管理员用户名重复
		boolean flag=adminDao.checkReg(username);
		if(flag){
			//注册成功
			adminDao.save(adminBean);
			//并将信息返回给添加界面
			resp.sendRedirect("add.jsp?status=1");
		}else{
			//注册失败
			resp.sendRedirect("add.jsp?status=2");
		}
		}
}
	/**
	 * 修改管理员信息，并未用到上面的方法，而是直接调用toUpdate的方法
	 * （跳转到添加add.jsp中同时设置一个updateBean session对象）
	 * 
	 * @param req
	 * @param resp
	 * @throws ServletException
	 * @throws IOException
	 */
  private void toUpdate(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException{
	  //定义接收字符类型
	  req.setCharacterEncoding("utf-8");
	  //将获取来自list.jsp中的id参数，并通过调用方法StringToInt来转换成int类型
	  int id=StringUtil.StringToInt(req.getParameter("id"));
	  if(id>1){
		  //为AdminDao类定义adminDao对象，并new一个空间
		  AdminDao adminDao=new AdminDao();
		  //为AdminBean实体类定义一个adminBean对象，并new一个空间？(错了)
		  //为AdminBean实体类定义一个adminBean对象，但调用dao中的通过id获取其他信息（如用户名密码）
		  AdminBean adminBean=adminDao.getById(id);//此处控制着传递的参数调取，通过传递在jsp中显示显示
		  //将通过传送id找到的adminBean通过Http储存工jsp界面调用（个人理解）？
		  req.setAttribute(Constants.SESSION_UPDATE_BEAN, adminBean);
		  //获取要跳转的界面？jsp中是也PrintWriter对象输出内容的
		  req.getRequestDispatcher("add.jsp").forward(req, resp);
		  
	  }else if(id==1){
		  resp.sendRedirect(req.getContextPath()+
				  "/admin/adminServlet?method=list&status=1");
	  }else{
		  resp.sendRedirect(req.getContextPath()+
				  "/admin/adminServlet?method=list&status=2");
	  }
  }
	
  /**
	 * 删除管理员信息
	 * 
	 * @param req
	 * @param resp
	 * @throws ServletException
	 * @throws IOException
	 * 请求与响应（Request、Response）
	 */
  private void delete(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
	  //作用是设置对客户端请求进行重新编码的编码。
	  req.setCharacterEncoding("utf-8");
	  //先将字符串转换成数字后再赋值给id变量
	  int id=StringUtil.StringToInt(req.getParameter("id"));
	  //通过id来判断要执行的情况，及界面上要显示的不同的status状态
	  if(id>1){
		  //此情况下能执行删除操作
		  //调用在AdminDao中编写的delete方法；
		  //定义AdminDao类的变量adminDao
		  AdminDao adminDao=new AdminDao();
		  //调用删除方法
		  adminDao.delete(id);
		  //执行成功后，执行相应的？重定向（sendRedirect）
		  resp.sendRedirect(req.getContextPath()+"/admin/adminServlet?method=list&status=3");
		  
	  }else if(id==1){
		  //超级管理员不能被删除的状况
		  resp.sendRedirect(req.getContextPath()+"/admin/adminServlet?method=list&status=1");
	  }else{
		  //?
		  resp.sendRedirect(req.getContextPath()+"/admin/adminServlet?method=list&status=2");
	  }
  }

	/**
	 * 退出登录
	 * 
	 * @param req
	 * @param resp
	 * @throws ServletException
	 * @throws IOException
	 */
	private void end(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String status = req.getParameter("status");
		if (status != null && "1".equals(status)) {
			req.getSession().invalidate();
			resp.sendRedirect(req.getContextPath() + "/admin/login.jsp");
		}
	}
}
