package com.cp.jsp.servlet.admin;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sun.org.mozilla.javascript.internal.json.JsonParser;

import com.alibaba.fastjson.JSON;
import com.cp.jsp.bean.ProductTypeBean;
import com.cp.jsp.dao.AdminDao;
import com.cp.jsp.dao.ProductTypeDao;
import com.cp.jsp.unit.StringUtil;
import com.sun.xml.internal.ws.api.ha.StickyFeature;


public class ProductTypeServlet extends HttpServlet {

	protected void service(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
		req.setCharacterEncoding("utf-8");
		String method=req.getParameter("method");
		if("toAdd".equals(method)){
			toAdd(req,resp);
		}else if("add".equals(method)){
			add(req,resp);
		}else if("list".equals(method)){
			list(req,resp);
		}else if("update".equals(method)){
			update(req,resp);
		}else if ("delete".equals(method)) {
 	 	 	delete(req, resp);
 	 	}else if("getType".equals(method)){
			getType(req,resp);
		}
	}
	/**
	 *显示分类
	 *@param req
	 *@param resp
	 **/
	
	private void list(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { 
		  
		  int parentId = StringUtil.StringToInt(req.getParameter("id")); 
		  //System.out.println("1");
		  ProductTypeDao productTypeDao = new ProductTypeDao(); 
		  
		  ProductTypeBean productTypeBean = productTypeDao.getType(parentId); 
		  
		  req.setAttribute("productTypeBean", productTypeBean); 
		  //System.out.println("2");
		  req.getRequestDispatcher("list.jsp").forward(req, resp); 
		  //System.out.println("3");
		 } 

	
	/**
	 *显示分类
	 *@param req
	 *@param resp
	 **/
	private void getType(HttpServletRequest req,HttpServletResponse resp)throws IOException{
		int parentId=StringUtil.StringToInt(req.getParameter("id"));
		ProductTypeDao productTypeDao=new ProductTypeDao();
		List<ProductTypeBean>typeList=productTypeDao.getTypeList(parentId);
		resp.setCharacterEncoding("utf-8");
		PrintWriter out=resp.getWriter();
		//JSON需要导入fastjson-1.2.8的包
		out.print(JSON.toJSONString(typeList));
		//flush是把流里的缓冲数据输出
		//close是把这个流关闭了，关闭之前会把缓冲的数据都输出。
		out.flush();
		out.close();
	}
	/**
	 *携带分类数据跳转到分类添加界面
	 *
	 *@param req
	 *@param resp
	 *@throws IOException
	 *@throws ServletException
	 **/
	private void toAdd(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{

		ProductTypeDao productTypeDao=new ProductTypeDao();
		
		List<ProductTypeBean>typeList=productTypeDao.getTypeBeans(0);
		
		req.setAttribute("productTypeList", typeList);
		
		req.getRequestDispatcher("add.jsp").forward(req, resp);
	}
	
	/**
	 *跳转到商品类型修改界面
	 *
	 *@param req
	 *@param resp
	 *@throws IOException
	 *@throws ServletException
	 **/
	private void update(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
		int id=StringUtil.StringToInt(req.getParameter("id"));
		
		//System.out.println("cishiwww获取的wwid为：" +id);
		
		ProductTypeDao productTypeDao =new ProductTypeDao();
		//通过id得到分类类型
		ProductTypeBean productTypeBean=productTypeDao.getTypeById(id);
		
		req.setAttribute("productTypeBean", productTypeBean);
		
		List<ProductTypeBean> typeList=productTypeDao.getTypeList(0);
		
		req.setAttribute("productTypeList", typeList);
		
		req.getRequestDispatcher("add.jsp").forward(req, resp);
		
	}
	 /**
		 * 删除管理员信息
		 * 
		 * @param req
		 * @param resp
		 * @throws ServletException
		 * @throws IOException
		 * 请求与响应（Request、Response）
		 */
	  private void delete(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
		  //作用是设置对客户端请求进行重新编码的编码。
		  req.setCharacterEncoding("utf-8");
          ProductTypeDao productDao=new ProductTypeDao();
          int id=StringUtil.StringToInt(req.getParameter("id"));
         // boolean f=false;
          productDao.delete(id);
          req.getRequestDispatcher("productTypeServlet?method=list");
	  }

	
	/**
	 *添加商品分类
	 *
	 *@param req
	 *@param resp
	 *@throws IOException
	 **/
	private void add(HttpServletRequest req,HttpServletResponse resp)throws IOException{
		//后面引号里获取的值是哪的？数据库还是界面
		String name=req.getParameter("name");
		//System.out.println("huiu"+name);
		int sort=StringUtil.StringToInt(req.getParameter("sort"));
		
		String intro=req.getParameter("desc");
		
		int id=StringUtil.StringToInt(req.getParameter("id"));
		
		//System.out.println("获取的id为：" +id);
		
		String [] parIds=req.getParameterValues("parentId");
		
		int parentId=0;
		//?
		for(String parId:parIds){
			parentId=Math.max(parentId, StringUtil.StringToInt(parId));
		}
		
		ProductTypeDao productTypeDao =new ProductTypeDao();
		
		boolean f;
		if(id==0){
			//添加新纪录
			ProductTypeBean productTypeBean=new ProductTypeBean(sort, parentId, name, intro);
			
			f=productTypeDao.add(productTypeBean);
		}else{
			//修改记录
			ProductTypeBean productTypeBean=new ProductTypeBean(id,sort, parentId, name, intro);
			
			f=productTypeDao.update(productTypeBean);
		}
        if(f){
			resp.sendRedirect("productTypeServlet?method=toAdd&status=true");
		}else{
			resp.sendRedirect("productTypeServlet?method=toAdd&status=false");
		}
		
	}
	
}
