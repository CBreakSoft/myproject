package com.cp.jsp.bean;

import java.util.List;

/**
*
*2017/05/126
*chenpeng
*商品分类的实现
*对应数据库中的Product_type
* 
*/
public class ProductTypeBean {

	//定义对应数据库中的变量
	private int id;//主键（自动递增）
	private String name;//商品分类名称
	private int parentId;//父分类id（本表里某条数据的id）
	private int sort;//序号
	private String intro;//简介
	private String createDate;//日期
	
	//定义list泛型
	private List<ProductTypeBean>childBeans;
	//定义类ProductTypeBean的变量parentBean
	private ProductTypeBean parentBean;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

	public int getSort() {
		return sort;
	}

	public void setSort(int sort) {
		this.sort = sort;
	}

	public String getIntro() {
		return intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public ProductTypeBean getParentBean() {
		return parentBean;
	}

	public void setParentBean(ProductTypeBean parentBean) {
		this.parentBean = parentBean;
	}
	
	public List<ProductTypeBean> getChildBeans() {
		return childBeans;
	}

	public void setChildBeans(List<ProductTypeBean> childBeans) {
		this.childBeans = childBeans;
	}
    //定义函数ProductTypeBean()
	public ProductTypeBean(){} 
	//带参数，这几个函数的作用？
	public ProductTypeBean(int id,String name){
		this.setId(id);
		this.setName(name);
	} 
	public ProductTypeBean(int sort,int parentId,String name,String intro){
		this.setSort(sort);
		this.setName(name);
		this.setParentId(parentId);
		this.setIntro(intro);
	} 
	
	public ProductTypeBean(int id,int sort,int parentId,String name,String intro){
		this.setId(id);
		this.setSort(sort);
		this.setParentId(parentId);
		this.setName(name);
		this.setIntro(intro);
	}
	
	public ProductTypeBean(int id,String name,int sort,String intro,String createDate){
		this.setId(id);
		this.setName(name);
		this.setSort(sort);
		this.setIntro(intro);
		this.setCreateDate(createDate);
	}
	public ProductTypeBean(int id,int sort,ProductTypeBean parentBean,String name,String intro,String createDate){
		this.setId(id);
		this.setSort(sort);
		this.setParentBean(parentBean);
		this.setName(name);
		this.setIntro(intro);
		this.setCreateDate(createDate);
	} 
	

}
