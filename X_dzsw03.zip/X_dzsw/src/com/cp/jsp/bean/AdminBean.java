package com.cp.jsp.bean;
/**
 *2017.5.6 
 *chenpeng
 *数据库admin表的信息(相当于ssh框架中的model)
 *
 */
public class AdminBean {
   private int id;
   private String username;
   private String password;
   private String salt;
   private String createDate;
   //需要get和set
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getSalt() {
	return salt;
}
public void setSalt(String salt) {
	this.salt = salt;
}
public String getCreateDate() {
	return createDate;
}
public void setCreateDate(String createDate) {
	this.createDate = createDate;
}
}
