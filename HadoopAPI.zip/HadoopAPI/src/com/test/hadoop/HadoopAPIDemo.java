package com.test.hadoop;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.junit.Before;
import org.junit.Test;


public class HadoopAPIDemo
{
	

	/**
	 * @param args
	 */
	
	FileSystem fileSystem;
	@Before
	public void init()throws IOException,URISyntaxException{
		//解析Hadoop文件，xxx-site.xml
		Configuration conf=new Configuration();
		fileSystem=FileSystem.newInstance(new URI("hdfs://hadoop:9000"), conf);
	}
	@Test
	public void testMkdir() throws Exception{
		/**
		 * 如果向HDFS写数据，需要有相应的权限
		 * 1、给HDFS的根目录 / 赋予普通用户权限
		 * 2、修改 hdfs-site.xml文件，把权限检查给关闭
		 * 3、执行的时候,选择Run Config~中的Arguments中的VM arguments里配置：（伪造hadoop用户  -DHADOOP_USER_NAME=hadoop）
		 * */
		boolean result = fileSystem.mkdirs(new Path("/aa/bb"));
		System.out.print(result);
	}
	
	/**
	 * 遍历目录，使用FileSysyem的listStatus（path）
	 * 如果查看file状态，使用fileStatus对象
	 * @throws Exception
	 * 
	 * */
	
	@Test
	public void list() throws FileNotFoundException, IllegalArgumentException,IOException{
		//FileStatus
		FileStatus[] fileStatuses=fileSystem.listStatus(new Path("/"));
		for (FileStatus fileStatus :fileStatuses)//迭代
		{
			System.out.println(fileStatus);//fileStatus
		}
	}
	
	
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		//解析hadoop的配置文件，xxx-site.xml
		
		Configuration conf = new Configuration();
		try
		{
			/**
			 * 默认情况下，读取的是本机的文件。如果想读取HDFS的文件，需要设置下协议
			 * FileSystem支持很多种的文件系统的读取，如HDFS，本机，FTP等
			 * 
			 */
			//该方式是访问虚拟机上的linux系统，需要配置路径信息  hadoop 192.168.117.11  来进行hdfs协议下的连接，hdfs://hadoop:9000连接操作
			//C:\Windows\System32\drivers\etc\hosts,点开编辑在最后面添加  192.168.117.11 hadoop
			//ctrl+t显示FileSystem下的方法
			
			FileSystem fileSystem = FileSystem.newInstance(new URI("hdfs://hadoop:9000"), conf);
			
			/*此方式是读取本地的LocalFileSystem
			FileSystem fileSystem=FileSystem.newInstance(conf);*/
			
		    System.out.println("fileSystem ："+fileSystem);
		    
		    /**
			 * HDFS的协议在core-site.xml文件中进行设置
			 */
		    
		    
		    Path path=new Path("/NOTICE.txt");
		    
		    //Path path=new Path("C:/Java/aa.txt");
		    
		    FSDataInputStream inputStream=fileSystem.open(path);
		    
		    IOUtils.copy(inputStream, System.out);
		    
		    inputStream.close();
		    
		} catch (Exception e)
		{
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}

}
