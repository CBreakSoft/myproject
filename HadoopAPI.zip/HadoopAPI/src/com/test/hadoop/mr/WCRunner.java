package com.test.hadoop.mr;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class WCRunner
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		try {
			Job job = new Job();
			
			job.setMapperClass(WCMapper.class);
			job.setReducerClass(WCReducer.class); 
			
			//在map阶段执行一次reduce，减少中间数据的产生
			job.setCombinerClass(WCReducer.class);
			
			/*本地模式
			FileInputFormat.setInputPaths(job, new Path(args[0]));
			FileOutputFormat.setOutputPath(job, new Path(args[1]));*/
			//半本地模式，需要配置
			FileInputFormat.setInputPaths(job,new Path("hdfs://hadoop:9000/wc/input"));
			FileOutputFormat.setOutputPath(job, new Path("hdfs://hadoop:9000/wc/output2"));
			
			job.setJarByClass(WCRunner.class);
			//map輸出的数据类型
			job.setMapOutputKeyClass(Text.class);
			job.setMapOutputValueClass(LongWritable.class);
			//reduce輸出的数据类型
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(LongWritable.class);
			
			//运行job
			job.waitForCompletion(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
